int main(void)
{
	while (1)
		;
	return (1);
}