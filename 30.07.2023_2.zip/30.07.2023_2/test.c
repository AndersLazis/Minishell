#include <stdlib.h>
#include <stdio.h>
int main(void)
{
	printf("tset\n");
	return (200);
}